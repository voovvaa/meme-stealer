# Repository Guidelines

## Project Structure & Module Organization
The entry point lives in `src/index.ts` and wires the Telegram bot, client session handling, and logging. Configuration helpers are under `src/config`, including `config.ts`, which loads `.env` values and validates required secrets. Core runtime logic is split across `src/services` (`telegramClient.ts`, `messageClientHandler.ts`, `handleCallbackQuery.ts`) and shared helpers in `src/utils` (`logger.ts`, `session.ts`). Build artifacts compile into `dist/`; avoid editing generated files directly. Keep any new runtime modules inside `src/` and group by feature to stay consistent.

## Build, Test, and Development Commands
Use `npm run start:dev` to launch the bot with `nodemon`, auto-reloading TypeScript files. Build production assets with `npm run build`, which writes compiled JavaScript to `dist/`. The production entry point is `npm start`. Maintain code quality with `npm run lint` (ESLint) and `npm run format` (Prettier). Run commands from the repository root, and commit only after a clean `npm run build && npm run lint`.

## Coding Style & Naming Conventions
This project targets Node.js with TypeScript 5.x. Follow Prettier defaults (2-space indentation, single quotes disabled in favor of double quotes) and run ESLint before pushing. Exported symbols use PascalCase for classes and camelCase for functions, variables, and file names (e.g., `handleCallbackQuery.ts`). Favor async/await and keep logging via the shared `logger` helper for consistent output.

## Testing Guidelines
There is no automated test suite yet; prioritize adding one as you extend the bot. Place new tests under `tests/` or colocated `__tests__/` directories and prefer lightweight frameworks such as Jest or Vitest with TypeScript support. When writing integration scenarios, mock Telegram network calls and assert side effects (saved sessions, logger messages). Document manual verification steps in pull requests until automated coverage exists.

## Commit & Pull Request Guidelines
Follow the existing history pattern: `<type>: <short description>` in lowercase (`feature:`, `bugfix:`, etc.). Keep subject lines under 70 characters and include context in the body when needed. For pull requests, provide a concise summary, list verification steps (commands run, manual checks), and link related issues. Add screenshots or logs for Telegram-facing changes when they aid reviewers. Ensure CI (if configured) and linting succeed before requesting review.

## Environment & Secrets
All Telegram credentials and channel identifiers are supplied via `.env`; copy `.env.example` if present or request one from the maintainers. Required keys include `API_ID`, `API_HASH`, `PHONE_NUMBER`, `TELEGRAM_PASSWORD`, and `BOT_TOKEN`. Never commit secrets or session files such as `sessionClient.txt`; add new sensitive files to `.gitignore` and confirm they are excluded before pushing.
